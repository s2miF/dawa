<?php
include_once ("include/header.php");
// include_once ("include/sidebar.php");
?>

<article class="col-md-9 col-lg-9 art_bg " style="margin-right : 160px">
<ol class="breadcrumb" class="pull-right">
  <li><a href="index.php">الرئسية</a></li>
  <li class="active">عنوان القسم</li>
</ol>
 <div class="col-lg-12">
 <div class="row">
 <div class="cate_post">
            <div class="col-md-3">
           <img src="http://english.republika.mk/wp-content/uploads/2014/08/fountain-pen-writing.jpg" width="100%" />
                </div>
               <div class="col-md-9">
                  <h2 class="cat_h2">عنوان المقاله</h2>
                <p>
 لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص
               </p>
			</div>  
			<div class="col-md-12">
			
			<hr style="margin-bottom : 9px;"/>
            <a href="#" class="btn btn-warning pull-left">إقراء المزيد</a> 
            <p class="pull-right"> <i class="fa fa-pencil" aria-hidden="true"></i><a href="profile.php"> سامي</a> | <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date("d-m-Y ");?></p>
            </div>
	   <div class="clearfix"></div>
</div> 
<div class="cate_post">
            <div class="col-md-3">
           <img src="http://english.republika.mk/wp-content/uploads/2014/08/fountain-pen-writing.jpg" width="100%" />
                </div>
               <div class="col-md-9">
                  <h2 class="cat_h2">عنوان المقاله</h2>
                <p>
 لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص
               </p>
			</div>  
			<div class="col-md-12">
			
			<hr style="margin-bottom : 9px;"/>
            <a href="#" class="btn btn-warning pull-left">إقراء المزيد</a> 
            <p class="pull-right"> <i class="fa fa-pencil" aria-hidden="true"></i><a href="profile.php"> سامي</a> | <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date("d-m-Y h:i:sa");?></p>
            </div>
	   <div class="clearfix"></div>
</div> 
<div class="cate_post">
            <div class="col-md-3">
           <img src="http://english.republika.mk/wp-content/uploads/2014/08/fountain-pen-writing.jpg" width="100%" />
                </div>
               <div class="col-md-9">
                  <h2 class="cat_h2">عنوان المقاله</h2>
                <p>
 لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص
               </p>
			</div>  
			<div class="col-md-12">
			
			<hr style="margin-bottom : 9px;"/>
            <a href="#" class="btn btn-warning pull-left">إقراء المزيد</a> 
            <p class="pull-right"> <i class="fa fa-pencil" aria-hidden="true"></i><a href="profile.php"> سامي</a> | <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date("d-m-Y");?></p>
            </div>
	   <div class="clearfix"></div>
</div> 
<div class="cate_post">
            <div class="col-md-3">
           <img src="http://english.republika.mk/wp-content/uploads/2014/08/fountain-pen-writing.jpg" width="100%" />
                </div>
               <div class="col-md-9">
                  <h2 class="cat_h2">عنوان المقاله</h2>
                <p>
 لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص
               </p>
			</div>  
			<div class="col-md-12">
			
			<hr style="margin-bottom : 9px;"/>
            <a href="#" class="btn btn-warning pull-left">إقراء المزيد</a> 
            <p class="pull-right"> <i class="fa fa-pencil" aria-hidden="true"></i><a href="profile.php"> سامي</a> | <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo date("d-m-Y h:i:sa");?></p>
            </div>
	   <div class="clearfix"></div>
</div>
 
 </div>
 </div>
</article>

<?php
include_once ("include/footer.php");
?>