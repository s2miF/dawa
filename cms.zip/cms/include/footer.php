</section>
<!-- end body -->

<!-- footer -->
<section class="container-fluid" style="margin-top: 20px;">
<div class="copyright">
        <div class="col-lg-8 col-sm-9 text-right" id="footertext"><a href="https://twitter.com/s2miF" style="color : #fff">powered by s2mi </a></div>
		<div class="col-lg-4 col-sm-4 text-left">
					<a href="#" target="_blank"><div class="twitter-hover social-slide"></div></a>
					<a href="#" target="_blank"><div class="facebook-hover social-slide"></div></a>
					<a href="#" target="_blank"><div class="google-hover social-slide"></div></a>
					<a href="#" target="_blank"><div class="instagram-hover social-slide"></div></a>
		</div>
	<div class="clearfix"></div>
</div>
  </div>
</section>
<!-- end footer -->
<?php close_db(); ?> 
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/form.js"></script>
    <script src="js/site_js.min.js"></script>
  </body>
</html>