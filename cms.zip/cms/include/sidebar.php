<?php include ("include/function.php"); ?>
<!-- السايد بار -->
		<aside class="col-md-3 clo-lg-3 sid_bg">
		<div class="col-md-12">
		<div class="row">

        <?php log_area(); ?>
		</div>
		</div>
		
		</aside>
<!-- نهاية السايد بار -->